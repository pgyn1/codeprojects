-module(cleanHanoi).
-export([create_towers/1, map_to_list/1, display_towers/1, move_towers/2, list_to_map/2, solve/1]).

solve([]) -> true;

solve(N) ->
	display_towers(N), % display the list before any changes.
	 [H1 | _T1] = N, 
	 [H2 | T2] = H1,
	 P = [T2, [], [H2]],
	 display_towers(P),
	 [H3 | T3] = T2, %H3 is now the head of T2
	 P1 = [T3, [H3], [H2]], 
	 display_towers(P1),
	 P2 = [T3, [], [H2, H3]],
	 display_towers(P2). 

	
%----------------------------------Completed functions below ---------------------

%Move the top disk from tower1 and place it onto tower 2. 
move_towers(List, Map) ->
	List = map_to_list(Map), % convert said map to a list,
	[Head | _Tail] = List, %extract the tuple from the list
	A = element(2, Head), %extract the list from the tuple called Head and assign it to 'A'
	[H | T] = A, %Given a list, split the list into a head element and a tail list
	D = maps:update(tower1, T, Map),
	E = maps:update(tower2, [H], D),%place the tail list in the first tuple and the head element in the second tuple.
	X = map_to_list(E),
	display_towers(X).

%move_towers(1, From, To, )
%move_towers(1, Src, Dst, List) ->

	
create_towers(0) -> []; %terminating case
create_towers(N) ->
	io:format("~n\tThe Revenge of the Towers of Hanoi ~n\tYou have selected ~p disk(s).~n", [N]), 
	#{ tower1=>lists:seq(1,N), tower2=>[], tower3=>[] }. %return a map with keys and lists. 

% display_towers takes in a list, It then splits said, list into a head element and a tail list 
%   we then print the current head element, 
% [xth:Last] is passed in, at which point a head | tail split will have H as the head and '[]' as the tail.	
display_towers([]) -> true; 
display_towers(List) ->  
	[H | T] = List, % Break the list into a head element and tail list.
	io:format("~p\n", [H]), %format for printing. 
	display_towers(T). %recursively calls display_towers.

%convert our map into a list, containing 3 tuples with associated lists. 
map_to_list(Map) ->
	A = maps:get(tower1, Map), %from key1, a given map: returns a list
	B = maps:get(tower2, Map), % from key2, a given map: returns a list : []
	C = maps:get(tower3, Map),
	[{towers1, A}, {towers2, B}, {towers3, C}]. %return a list with 3 tuples, containing respective list. 

%converting a list to a map
list_to_map(Map, List) ->
	%update first then convert update to a list
	[H | _T] = List, %split list,
	A = element(2, H),  %grabbed list here
	Update = maps:update(tower1, A , Map),
	Update.