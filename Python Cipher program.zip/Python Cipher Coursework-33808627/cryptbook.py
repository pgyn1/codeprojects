import string  # random ASCII to fill grid if need be (lowercase)
import math  # Creating a matrix
import time  # Aesthetics (Pleasurable for viewing)
import random

# ------------------------------------------MODULE------------------------------------------------------#
# -------------------------------------Helper & transitive functions------------------------------#


def cycle_and_print(list_to_cycle):
    """
    :param list_to_cycle: A list to be cycled through.
    :returns Output for user view: grid to print in order to display information.
    :rtype: formatted object
    """
    for reg in list_to_cycle:
        time.sleep(0.5)
        print("{0}".format(reg))


def grab_int_to_ascii(int_i):
    """
    # Takes in an index value and returns an ascii label (012345 = ABCDEF)
    :param int_i: the x or y coordinate to be labelled and substituted
    :returns label: a character in the ascii table grabbed via an increment on an index number
    :rtype: a char
    """

    j = int_i + 65
    label = chr(j)
    return label


def list_to_string(a_list):
    """
    :param a_list: the list to be converted into a string
    :returns a_string: take a list and output a string
    :rtype: a string
    """

    a_string = ''
    for item in a_list:
        a_string += item
    return a_string


def unique_me(stringy):
    """
    :param stringy: The message to be refined
    :returns stringy_done: a string containing only desirable elements of user input, in this case, no repeated chars
    :rtype: a string
    """
    result = []
    for character in stringy:
        if character not in result:
            result.append(character)

    stringy_done = list_to_string(result)
    return stringy_done


def remove_unwanted_char(mesh):
    """
    :param mesh:the message to be refined
    :returns tidy_msg: a string containing only desirable elements of user input
    :rtype: a string
    """
    array_to_hold_removable_chars = ";¬`%^&*\"\t\n():/£$|\>=<*[]_'#,.!?{}~-+¬ @"
    final_array = list(array_to_hold_removable_chars)

    for i in final_array:
        mesh = mesh.replace(i, "")

    tidy_msg = mesh
    return tidy_msg


def return_matrix(m, k):
    """
    # returns a matrix to cycle through and prepare for readings
    :param k: the keyword that sits at the top ready for oolumnar transposition or to evaluate the no. of cols in decry.
    :param m: the message to be used to create the matrix for transpo reasons or evaluation in decryption. 'AA BB FF'
    :returns matrix: an n x n cipher grid, used for transposition and decryption
    :rtype: a list
    """
    msg = m  # 'FA BB DC...'
    message = remove_unwanted_char(msg)
    # print("Message stripped success: " + message)

    key = k  # must be greater than one or else no transpose

    cedix = key + message
    length_of_msg = len(message)
    length_of_key = len(key)
    try:
        # To ensure the grid is filled completely,
        # the length of the first cipher_text must be divisible by the length of the keyword
        # the result of the division will provide the number of rows for the grid
        num_of_matrix_rows = math.ceil(length_of_msg / length_of_key) + 1

        # the cedix string containing key+message must be equal rows so we may need to increment with lowercase ascii #
        for x in range((length_of_key - (length_of_msg % length_of_key))):
            cedix += random.choice(string.ascii_letters).lower()

        # matrix will hold our values
        matrix = [[cedix[b + (a * length_of_key)] for b in range(length_of_key)] for a in range(num_of_matrix_rows)]
        return matrix

    except (ZeroDivisionError, IndexError):
        print("\nFailed to create a matrix")


def make_valid(keys):
    """
    # FOR : transpose and decode inputs (keyword)
    :param keys: The keyword to be made valid for operations
    :returns keys_hack: a keyword refined
    :rtype a string
    """
    keys_sigma = keys.lower()
    keys_trix = remove_unwanted_char(keys_sigma)
    keys_hack = unique_me(keys_trix)

    keys_back = str(keys_hack)
    return keys_back


# ---------------------------- MESSAGES AND PRINT ORGANISATION/STRUCTURE----------------#
f1 = "\n\n**********************************************************************"
f2 = "\n**************Hide messages and secrets at your will******************"
f3 = "\n**********************************************************************"
f4 = "\n1.Encrypt Msg 2.Transpose message 3.Decrypt Msg, 4.quit"

f5 = "\n**********************Encryption Phase********************************"
f6 = "\n**********************Transposition Phase*****************************"
f7 = "\n**********************Decryption Phase********************************"
f8 = "\n**********************************************************************"

inv_err1 = "\n\n***Invalid input***"
inv_err2 = "\nThe arithmetic is crucial here."
inv_err3 = "\nPlease try again - use the same keyword that you *used* for transpose"
inv_err4 = "\nUse the same final_cipher_text that you *received* from transpose"
