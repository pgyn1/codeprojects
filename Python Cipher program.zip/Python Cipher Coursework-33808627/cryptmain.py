import textwrap  # Group string by n and return list
import random   # That old cipher grid randomised
import time  # Aesthetics (Pleasurable for viewing)
import cryptbook  # My module manual, containing helper & transitive functions and string constants

# ----------------------------------------

GROUP_BY = 2
CipherGrid = [['8', 'P', '3', 'D', '1', 'N'],
              ['L', 'T', '4', 'O', 'A', 'H'],
              ['7', 'K', 'B', 'C', '5', 'Z'],
              ['J', 'U', '6', 'W', 'G', 'M'],
              ['X', 'S', 'V', 'I', 'R', '2'],
              ['9', 'E', 'Y', '0', 'F', 'Q']]


# ------------------------------------Main Functions-------------------------------------------------#

def encrypt_message(nth_letter):
    """
    :param nth_letter: this is the iteration through the stripped message a user wishes to be encrypted.
    :returns formatted first cipher_text
    :rtype: object
    """
    if nth_letter.isalnum():  # only alpha numerical chars permitted
        for x in range(len(CipherGrid)):  # x will iterate through the matrix
            label_row = cryptbook.grab_int_to_ascii(x)
            row = CipherGrid[x]  # 1st time; row = CipherGrid[0] ('8','P','3'...)
            row_string = cryptbook.list_to_string(row)  # 8P3...
            if row_string.__contains__(nth_letter.upper()):    # checks if row contains char in uppercase conditions
                y = row_string.index(nth_letter.upper())        # returns index of aChar in rowString
                label_col = cryptbook.grab_int_to_ascii(y)
                print("{0}{1}".format(label_row, label_col), " ", end="")  # Print  then the row index + the column (x,y)
    else:
        nth_letter = ''  # replace with blank
        print(nth_letter, end="")


def encrypt_message_start_main(plaintext):

    string_stripped = cryptbook.remove_unwanted_char(plaintext)
    plain_txt_list = list(string_stripped)  # convert user input to list and store in plain_text

    if len(plain_txt_list) < 1 or len(plain_txt_list) > 60:
        print("You must input a message and it must be <= 60 chars. ")
        print("The length of your message is: {0}".format(str(len(plain_txt_list))))
    else:
        print('\n***Your plaintext to be encrypted: ***')
        print(plain_txt_list)

        random.shuffle(CipherGrid)  # Different cipher_text each run of the program.

        print("\n***Your first cipher_text: ***")
        for letter in plain_txt_list:  # cycle through the chars in the plain_text.
                    encrypt_message(letter)  # Upon each iteration, use the function on the char.

        print("\n\nCipher Grid Used:")
        cryptbook.cycle_and_print(CipherGrid)

# ------------------------------------------------------------------------------

def transpose_message(aChar, c):
    """
    :param aChar: the first letter in a string to be searched in the grid 'c'
    :param c: the matrix grid that will be searched alphabetically

    :returns a string transposed
    :rtype: string or unicode
    """
    medix = ''
    row = c[0]  # 'key' (1st time round)
    row_string = cryptbook.list_to_string(row)  # refers to the Matrix rows # 'k' 'e' 'y'
    if row_string.__contains__(aChar) or row_string.__contains__(aChar.upper()):  # searches through this grid (*1)
        y = row_string.index(aChar)
        col = [column[y] for column in c]  # read  columns wise and return as a list
        # del col[0]
        for z in col:
            if z.isalnum():  # need to have is upper in case you get a filler which will be lower case
                medix += z

    return medix


def transpose_message_start_main(initial_cipher_txt, key_ID):

    first_text = cryptbook.remove_unwanted_char(initial_cipher_txt)  # remove the spaces received from encryption phase
    first_cipher_text = first_text.upper()

    keyword = cryptbook.make_valid(key_ID)  # unique, remove_unwanted, lowercase

    if len(keyword) > 0 and len(first_cipher_text) > 0:
        if len(keyword) <= 6:
            q = cryptbook.return_matrix(first_cipher_text, keyword)  # returns a matrix based on the msg + key
            print("\nFirst CipherText to be transposed: {0}".format(first_cipher_text))
            print("\n***New matrix with keyword and NO repeated letters: ***")
            cryptbook.cycle_and_print(q)

            # ------Grid User view & Final Cipher_text out-----------------#

            # We're going to check row[0] consistently with the sorted version
            # To grab the columns in the transposed order and rebuild row-wise for reading.
            aSortedKey = sorted(keyword)

            hack = []  # List to be appended and cycled for user view

            print("\n***Your final cipher_text: ***")
            for xon in aSortedKey:
                r = transpose_message(xon, q)  # returns a string transposed
                vox = list(r)
                # grab the transposed row string (converted tolist) with lowerCasePointer & add to list 'hack'
                hack.append(vox) # for user view
                print(r, end="")  # FinalCipherText with lowercase pointers.

            print("\n\n***Grid sorted alphabetically & read row-wise to obtain Final CipherText: ***")
            cryptbook.cycle_and_print(hack)
        else:
            print("{0}".format(cryptbook.inv_err1) + "\nThe length of the keyword must be <= 6")
            print("The length of \"{0}\" with no repeated chars is: {1}".format(keyword, str(len(keyword))))

    else:
        print("{0}".format(cryptbook.inv_err1) + "\nCannot enter an empty keyword or first_cipher_text.")
        print("The length of \"{0}\" with no repeated chars is: {1}".format(keyword, str(len(keyword))))
        print("The length of \"{0}\" is: {1}".format(first_cipher_text, str(len(first_cipher_text))))

# ------------------------------------------------------------------------------

def decrypt_transpose_message(original_word, trans_grid):
    """
    :param original_word: the keyword in input order (not sorted) nth letter
    :param trans_grid: the matrix which we recreated with the return_matrix function, will be searched to get reordered
                       cipher grid as it were in the transposition phase

    :returns sax: a list_string , which is a reordered creation of the matrix used in the transposition phase
                  this is in order to evaluate it, in order to grab the number of columns and more importantly
                  to read it column wise to grab the original ciphertext.
    :rtype: string
    """
    for xp in range(len(trans_grid)):
        rowyun = trans_grid[xp]  # 'dDBFEDFBAD' (1st time round)
        row_string_yun = cryptbook.list_to_string(rowyun)  # refers to the Matrix rows # dDBFEDFBAD
        if row_string_yun.__contains__(original_word):    # checks if row contains char in uppercase conditions
                y5 = row_string_yun.index(original_word)        # returns index of aChar in rowStrin
                sax = cryptbook.list_to_string(trans_grid[xp])  # Print  then the row index + the column (x,y)
                return sax


def decrypt_message(cipher_text, keyID):
    """
    :param cipher_text: The final cipher_text - received from the transposition phase - to be decoded
    :param keyID: The keyword (and its length) used in the transposition phase - to rebuild a grid with the correct number of cols

    :returns: NULL, this method formats output which is sufficient in and of itself.
    :rtype: object
    """
    if len(keyID) <= 0 or len(cipher_text) <= 0 or cipher_text.isupper() == True:  # first cipher text will be upper
        print("{0}".format(cryptbook.inv_err1))
        print("The length of keyword you input: {0}".format(str(len(keyID))))
        print("\nCipher text must be > 0 and it must be the *final* cipher_text")
        print("The cipher text you provided was: {0}".format(cipher_text))
    else:
        keyzword = cryptbook.make_valid(keyID)
        time.sleep(0.5)
        print("\nIn case you made a mistake or forgot to remove repeated chars...")
        time.sleep(1.2)
        print("I cleaned up your keyword and made it valid: {0}".format(keyzword))
        time.sleep(1.6)

        print()
        try:
            # -----------------------------------REVERSE TRANSPOSITION--------------------------------------------#
            # print(cipher_text)
            # create a new matrix, with the cipher text and keyword, we will need this, to figure out the number
            # that we group the final cipher text by, this will provide us with an avenue to discover number of columns
            # the transposed cipher_text had.
            f = cryptbook.return_matrix(cipher_text, keyzword)

            list_me = textwrap.wrap(cipher_text, len(f)-1)  # input the number of columns in f , minus one: 0-7 == 1-8
            # we now have a list with the same number of columns that the transposed reading provided us with
            # we will later use this as a matrix that is searched through with the original  ordered keyword as the list

            tempo = []  # create an empty list, that will store the row string as an element in a new matrix

            # cycle through the keyword (in original order) so we read the columns in the order before transposition
            for helm in keyzword:
                # take list_me as the matrix to be searched and helm as a letter to be reverse transposed
                rex = decrypt_transpose_message(helm, list_me)
                # remove lowercase labels or pointer if you will, that label the original order of the first ciphertext
                shades = rex[1:]
                # append row string as the first element in empty tempo list, much the same for the rest of elements.
                tempo.append(shades)
                # We now have the original order of the cipher_text minus the lowercase labels
            print("**Recreated Cipher grid as it were at transposition**")
            print("***Read columns wise - provides the original cipher_text before transposition: ***")

            # -----------User view & instructions to grab the number of columns to cycle through------#
            # -----the length of the final counter string will equal the number of columns in our tempo
            # -----that we need to cycle through and reverse transpose (instead of row-wise, column wise)---#

            # @Counter: will ultimately contain a row_string, the length of this row_string is what
            # we'll use as a range to make sure we grab all columns when rebuilding the original cipher_text
            # before transposition.
            counter = ""

            pack = []  # List to hold lists, to be cycled through for user view.

            for ikt in tempo:  # cycle through the newly appended matrix(list), and gather the number of columns
                deep = list(ikt)  # remember, tempo is a list containing elements of STRINGS.
                pack.append(deep)  # for user view
                counter = ikt  # little hack here to force it to overwrite, because the length of the final string..

            cryptbook.cycle_and_print(pack)

            # the number of columns - we'll need as range to read all the labels down and right
            print("\nThe number of columns read: {0}".format(str(len(counter))))

            medi = ''  # create an empty string
            for tox in range(len(counter)):  # cycle through tempo in the range of the counter length 
                colz = [column[tox] for column in tempo]  # grab a column  ( as a list)
                sap = cryptbook.list_to_string(colz)  # turn it into a string
                medi += sap  # increment it to our empty medi string

            zedi = ''  # create an empty string
            for izzy in medi:  # cycle through the medi string
                if izzy.isupper():  # only collect the uppercase ( this is to remove any filler lower chars)
                    zedi += izzy  # append those accepted to our zedi empty string

            print("The original cipher_text before transposition: {0}".format(zedi))  # print the original cipher

            # -----------------------------------REVERSE ENCRYPTION-----------------------------------------------#
            print("\n************original_message_in_uppercase*******************")

            # The group by constant that will wrap the list elements in twos, in order to find x and y coordinates
            # take the original cipher and group in 2s to get the x and y coordinates together as elements
            list_of_ciphers = textwrap.wrap(zedi, GROUP_BY)  # return [aString[k:k+n] for k in range(0, len(aString), n)]

            for ime in list_of_ciphers:  # iterate through list of ciphers, in this example we'll use- ['DE', 'BA', 'BE', ...]
                list_of_element = list(ime)  # MAKE a new list from the element 'DE' to get for example - ['D', 'E']
                try_work = ''
                try:
                    x2 = list_of_element[0]  # grab 'D' from new list by index. (or the 1st of two ele's in a new list)
                    y2 = list_of_element[1]  # grab 'E' from new list by index. (or the 2nd of two ele's in a new list)
                    take_away_from_this_ord_row = ord(x2)  # get the ordinal integer of 'D'
                    this_is_the_row_pre_encode = take_away_from_this_ord_row - 65  # - 65 from ordinal of 'D' - origi idx num

                    take_away_from_this_ord_col = ord(y2)  # get the ordinal integer of 'E'
                    this_is_the_col_pre_encode = take_away_from_this_ord_col - 65  # - 65 from ordinal of 'E' - origi idx num

                    # Access the value and print the char with no new lines.
                    try_work += CipherGrid[this_is_the_row_pre_encode][this_is_the_col_pre_encode]
                    try_work += "-"
                except IndexError:
                    continue  # if this coordinate was out of index, we can still recover most of the message
                print("{0}".format(try_work), end="")
            print("\n************************************************************")
            print("\nReasons for unexpected output: ")
            print("1. Use the same keyword and final cipher_text. In the same order.")
            print("2. If you encrypt another message before you decrypt - the CipherGrid shuffles.")

        except (TypeError, IndexError, ZeroDivisionError):
            print("{0}{1}{2}".format(cryptbook.inv_err1, cryptbook.inv_err2, cryptbook.inv_err3))
            print("The keyword you entered was: {0}".format(str(keyzword)))
            print("{0}".format(cryptbook.inv_err4))
            print("The final Cipher_text you provided was: {0}".format(str(cipher_text)))

        # and there you have the decrypted message.


# ----------------------------------------------Main--------------------------------------------------#
def main():
    """
    Presents a user with options to encrypt and decrypt data
    We infinitely present these options in a while loop, while the user wishes to run the script.

    Certain functions are then called depending upon the option the user selects.
    This function essentially controls the flow of the script.
    """

    choice = 0
    while choice != "4":
        print("{0}{1}{2}{3}".format(cryptbook.f1, cryptbook.f2, cryptbook.f3, cryptbook.f4))
        choice = input('Enter your choice number: ')

        # -----------------ENCODE A MESSAGE---------------------------------------------------------
        if choice == "1":
            print("{0}{1}".format(cryptbook.f5, cryptbook.f8))
            plain_text = input('Enter message: ')  # prompt
            encrypt_message_start_main(plain_text)

        # --------------TRANSPOSE A MESSAGE----------------------------------------------------
        elif choice == "2":
            print("{0}{1}".format(cryptbook.f6, cryptbook.f8))
            firstciphertext = input("Enter the first cipher_text: ")
            keyt = str(input("Enter your keyword, no longer than 6 chars: "))  # say it was "markk"
            transpose_message_start_main(firstciphertext, keyt)

        # ------------DECRYPT A MESSAGE---------------------------------------------------------------
        elif choice == "3":
            print("{0}{1}".format(cryptbook.f7, cryptbook.f8))
            finalciphertext = input("Enter the *final_cipher_text* here: ")
            keyd = input("Enter keyword you used at transposition phase: ")
            decrypt_message(finalciphertext, keyd)  # ('The Cipher_text', keyword)

if __name__ == "__main__":
    main()
