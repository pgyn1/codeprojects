//SCC212 Advanced Programming 
//Object-Oriented Programming Coursework 1

@SuppressWarnings("serial")
public class Planet extends Star{
	
	public Planet(double distance, double angle, double diameter, String colour, double speed){
	    super(distance, angle, diameter, colour, speed);
	}
   
}
