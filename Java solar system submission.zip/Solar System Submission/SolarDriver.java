//SCC212 Advanced Programming 
//Object-Oriented Programming Coursework 1

public class SolarDriver {

public static void main(String[] args){
    
	//Create a pointer to an object on the heap and name the pointer "milkyWay"
    SolarSystem milkyWay = new SolarSystem(1360, 929);
    milkyWay.setResizable(false);
    milkyWay.setLocationRelativeTo(null);
   
    //Instances of each object in the solar system
    //Distance, angle, diameter, colour, speed.
     //my very easy method just speeds up naming (planets(pluto?))
    Star sun = new Star(0, 0, 120, "YELLOW", 0);
    Planet mercury = new Planet(100, 45, 20, "LIGHTGREY" ,4.25);
    Planet venus = new Planet(130, 45, 21, "ORANGE", 2.95);
    Planet earth = new Planet(170, 45, 24, "BLUE", 1.35);  
    Planet mars = new Planet(200, 45, 24, "RED", 1.0);
    Planet jupiter = new Planet(300, 45, 65, "ORANGE", 0.8);
    Planet saturn = new Planet(340, 45, 35, "ORANGE", 0.6);
    Planet uranus = new Planet(380, 45, 28, "CYAN", 0.4);
    Planet neptune = new Planet(420, 45, 25, "BLUE", 0.2);
    
    //Planetary singular Moons'
    Moon moon = new Moon(25, 30, 8, "LIGHTGREY", 1.5);
    
    //Jupiter's Moons
    //Create an array of moons for Jupiter's ring.
    Moon [] jMoons = new Moon[63];
    
    //Cycle through each instance and assign the object reference to point to object on the heap
    for(int x = 0; x < jMoons.length; x++){
    	 jMoons[x] = new Moon((double)Math.random()*24+41,(double)Math.random()*359+1, (double)Math.random()*4+8, "DARKGREY", 0.5);
    }
    
    //Create an Array of stars for Asteroid Belt
    AsteroidBelt [] stars = new AsteroidBelt[900];
    
    //Cycle through the length of the stars array and assign each object reference to an object on the heap. 
    for(int i=0; i<stars.length;i++){
     	stars[i] = new AsteroidBelt((double)Math.random()*320+200,(double)Math.random()*359 + 1, (double)Math.random()*10, "CYAN", 0.3);
    }
    
    //Array for Saturn's rings.
    Moon [] sRings = new Moon[95];
    
    //Cycle through Saturn's Rings
    for(int i=0; i<sRings.length; i++){
    	sRings[i] = new Moon(45,(double)Math.random()*359+1, (double)Math.random()*4+8, "DARKGREY", 1.5);
    	//if((boolean) (i >= 100 ? i+= 100-1 : i=i+1)); 
    }
    
    while(true){
        
    	//Stars, planets and belts are drawn onto the Milkyway.
    	//Return values using the accessors in the PointSpace class.
        milkyWay.drawSolarObject(sun.returnDist(), sun.returnAngle(), sun.returnDiam(), sun.returnCol()); //Sun doesn't need to move.
        milkyWay.drawSolarObject(mercury.returnDist(), mercury.motion(), mercury.returnDiam(), mercury.returnCol() );
        milkyWay.drawSolarObject(venus.returnDist(), venus.motion(),venus.returnDiam(), venus.returnCol());
        milkyWay.drawSolarObject(earth.returnDist(), earth.motion(), earth.returnDiam(), earth.returnCol());
        milkyWay.drawSolarObject(mars.returnDist(), mars.motion(), mars.returnDiam(), mars.returnCol());
        milkyWay.drawSolarObject(jupiter.returnDist(), jupiter.motion(), jupiter.returnDiam(), jupiter.returnCol());
        milkyWay.drawSolarObject(saturn.returnDist(), saturn.motion(), saturn.returnDiam(), saturn.returnCol());
        milkyWay.drawSolarObject(uranus.returnDist(), uranus.motion(), uranus.returnDiam(), uranus.returnCol());
        milkyWay.drawSolarObject(neptune.returnDist(), neptune.motion(), neptune.returnDiam(), neptune.returnCol());
      
        
        //Planetary moons.
   		//Use a particular planet's point in space as the point for moon objects to orbit "about"
 		milkyWay.drawSolarObjectAbout(moon.returnDist(),moon.returnAngle() + moon.motion(), moon.returnDiam(), moon.returnCol(), earth.returnDist(), earth.returnAngle());
 		milkyWay.drawSolarObjectAbout(moon.returnDist(),moon.returnAngle() + moon.motion(), moon.returnDiam(), moon.returnCol(), mars.returnDist(), mars.returnAngle());
       
 		//Draw Jupiter's Moons
 		for(int i=0; i<63; i++){
 			milkyWay.drawSolarObjectAbout(jMoons[i].returnDist(), jMoons[i].returnAngle() + jMoons[i].motion(), jMoons[i].returnDiam(), jMoons[i].returnCol(), jupiter.returnDist(), jupiter.returnAngle());
 		}
 		
 		//Draw Saturn's rings
 		for(int i=0; i<25; i++){
 			milkyWay.drawSolarObjectAbout(sRings[i].returnDist(), sRings[i].returnAngle() + sRings[i].motion(), sRings[i].returnDiam(), sRings[i].returnCol(), saturn.returnDist(), saturn.returnAngle());
 		}
 		
 		//The Asteroid Belt
 		//Loop again through stars array to draw and prevent OutOfBoundArrayIndex
 		for(int i=0; i<900; i ++){
 			milkyWay.drawSolarObject(stars[i].returnDist(), stars[i].returnAngle() + stars[i].motion(), stars[i].returnDiam(), stars[i].returnCol());
 		}
 		
 		milkyWay.finishedDrawing();
     
    }//End While loop
  }//End Main
}//End Class

