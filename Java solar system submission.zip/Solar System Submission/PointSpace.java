//SCC212 Advanced Programming 
//Object-Oriented Programming Coursework 1

@SuppressWarnings("serial")
public class PointSpace extends SolarSystem {
	
	private String colour; //declare a private variable of String type (class)
	private double distance; // declare a private variable named distance of type double. 
	private double angle;
	private double diameter;
	private double speed;
	
	//Default Constructor 
	public PointSpace(){
		super(1, 1);
	}
	
	//Constructor for pass by value
	public PointSpace(double distance, double angle, double diameter, String colour, double speed){
	   super(distance,angle,diameter,colour,speed);
	    this.colour = colour;
	    this.distance = distance; // "This" instance of distance
	    this.angle = angle; //"This" particular instance of angle...
	    this.diameter = diameter;
	    this.speed = speed;
	}
	
	//Moveable
	public double motion(){
		angle = angle + speed;
		return angle;
	}

	//Accessors
	public String returnCol(){
	    return colour;
	}

	public double returnDist(){
	    return distance;
	}
	public double returnAngle(){
	    return angle;
	}
	public double returnDiam(){
	    return diameter;
	}
	
	public double returnSpeed(){
	    return speed;
	}
	
	


}